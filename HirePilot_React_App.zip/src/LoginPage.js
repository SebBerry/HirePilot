import React, { useState } from 'react';

function LoginPage({ onLogin }) {
  const [email, setEmail] = useState('');

  return (
    <div className="center">
      <h2>Login to HirePilot</h2>
      <input
        type="email"
        placeholder="Your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <button onClick={onLogin}>Continue</button>
    </div>
  );
}

export default LoginPage;