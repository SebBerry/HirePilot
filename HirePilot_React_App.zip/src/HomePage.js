import React from 'react';

function HomePage({ onSelect }) {
  return (
    <div className="center">
      <h1>Welcome to HirePilot</h1>
      <p>AI-powered recruiting for candidates and companies</p>
      <button onClick={() => onSelect('candidate')}>I'm a Candidate</button>
      <button onClick={() => onSelect('recruiter')}>I'm a Recruiter</button>
    </div>
  );
}

export default HomePage;