import React from 'react';

function RecruiterPage() {
  return (
    <div className="center">
      <h2>Post a Job</h2>
      <input type="text" placeholder="Job Title" />
      <textarea placeholder="Job Description"></textarea>
      <button>Post</button>
    </div>
  );
}

export default RecruiterPage;