import React, { useState } from 'react';
import HomePage from './HomePage';
import CandidatePage from './CandidatePage';
import RecruiterPage from './RecruiterPage';
import LoginPage from './LoginPage';
import Chatbot from './Chatbot';

function App() {
  const [userType, setUserType] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  if (!isLoggedIn) return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  if (!userType) return <HomePage onSelect={setUserType} />;

  return (
    <>
      {userType === 'candidate' ? <CandidatePage /> : <RecruiterPage />}
      <Chatbot userType={userType} />
    </>
  );
}

export default App;