import React from 'react';

function CandidatePage() {
  return (
    <div className="center">
      <h2>Upload Your Resume</h2>
      <input type="file" />
      <p>Our AI will help match you to jobs!</p>
    </div>
  );
}

export default CandidatePage;