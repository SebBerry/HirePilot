import React from 'react';

function Chatbot({ userType }) {
  return (
    <div className="chatbot">
      <p>👋 Hi {userType}! Ask me anything about jobs or hiring.</p>
    </div>
  );
}

export default Chatbot;